# Desarrollo de Software V

## Líderes
- Brando
- Luis